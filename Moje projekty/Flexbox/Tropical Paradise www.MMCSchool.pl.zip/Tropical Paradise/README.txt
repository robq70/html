Projekt z kursu "Kurs Tworzenia Stron WWW cz. 3".
Kurs dostępny na www.MMCSchool.pl 

P.S. Dodajcie swój kit z FontAwesome! ;)